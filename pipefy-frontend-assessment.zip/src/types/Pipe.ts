export type Pipe = {
  id: string;
  cardsCount: number;
  name: string;
};
